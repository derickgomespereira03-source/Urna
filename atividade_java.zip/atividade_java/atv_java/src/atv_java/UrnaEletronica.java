package atv_java;

import javax.swing.JOptionPane;

public class UrnaEletronica {

    public static void main(String[] args) {

        String[] candidatos = {"Lula", "Flávio Bolsonaro", "Renan Santos"};
        int[] votos = new int[candidatos.length];

        int eleitores = Integer.parseInt(
                JOptionPane.showInputDialog("Digite a quantidade de eleitores:")
        );

        for (int i = 1; i <= eleitores; i++) {

            String mensagem = "ELEITOR " + i + ", ESCOLHA SEU CANDIDATO:\n\n"
                    + "1 - Lula\n"
                    + "2 - Flávio Bolsonaro\n"
                    + "3 - Renan Santos";

            int opcao = Integer.parseInt(
                    JOptionPane.showInputDialog(mensagem)
            );

            if (opcao >= 1 && opcao <= 3) {
                votos[opcao - 1]++;
            }
            else {
                JOptionPane.showMessageDialog(
                        null,
                        "Opção inválida. Escolha 1, 2 ou 3."
                );
                i--;
            }
        }

        // Descobre o maior número de votos
        int maior = votos[0];
        for (int i = 1; i < votos.length; i++) {
            if (votos[i] > maior) {
                maior = votos[i];
            }
        }

        String resultado = "===== APURAÇÃO =====\n\n";

        for (int i = 0; i < candidatos.length; i++) {
            resultado += candidatos[i] + ": " + votos[i] + " voto(s)\n";
        }

        // Verifica quem venceu (ou se houve empate)
        String vencedores = "";
        int quantos = 0;
        for (int i = 0; i < candidatos.length; i++) {
            if (votos[i] == maior) {
                if (quantos > 0) {
                    vencedores += " e ";
                }
                vencedores += candidatos[i];
                quantos++;
            }
        }

        if (quantos == 1) {
            resultado += "\nVENCEDOR: " + vencedores;
        } else {
            resultado += "\nEMPATE entre: " + vencedores;
        }

        JOptionPane.showMessageDialog(null, resultado);
    }
}